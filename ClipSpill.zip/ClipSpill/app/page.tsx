export default function Home() {
  return (
    <main className="mx-auto flex min-h-screen max-w-5xl items-center px-8">
      <div className="space-y-5">
        <p className="text-lg font-bold text-lime-300">◈ ClipSpill</p>
        <h1 className="max-w-2xl text-5xl font-bold tracking-tight md:text-7xl">Your next video is in the comments.</h1>
        <p className="max-w-lg text-lg text-neutral-300">Turn the questions your audience keeps asking into Shorts and Reels.</p>
      </div>
    </main>
  );
}
